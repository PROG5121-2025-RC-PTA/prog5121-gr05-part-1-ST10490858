/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

import java.util.ArrayList;

/**
 *
 * @author RC_Student_lab
 */
public class Arraylist {
   

        static ArrayList<Message> sentMessage = new ArrayList();
        static ArrayList<Message> disregardedMessages= new ArrayList();
        static ArrayList<Message> storedMessages = new ArrayList();
        static ArrayList<Message> messagesHashes = new ArrayList();
        static ArrayList<Message> messageID = new ArrayList();
        
    }
    



