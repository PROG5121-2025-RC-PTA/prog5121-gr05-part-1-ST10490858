/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class MessageSystem {
    
    public static class Message {
        private final String messageId;
        private final String recipient;
        private final String developer;
        private final String content;
        private final String flag;
        
        public Message(String messageId, String recipient, String developer, String content, String flag) {
            this.messageId = messageId;
            this.recipient = recipient;
            this.developer = developer;
            this.content = content;
            this.flag = flag;
        }
        
        public String getMessageId() {
            return messageId;
        }
        
        public String getRecipient() {
            return recipient;
        }
        
        public String getDeveloper() {
            return developer;
        }
        
        public String getContent() {
            return content;
        }
        
        public String getFlag() {
            return flag;
        }
        
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Message message = (Message) o;
            return Objects.equals(content, message.content);
        }
        
        @Override
        public int hashCode() {
            return Objects.hash(content);
        }
    }
    
    private final List<Message> messages;
    
    public MessageSystem() {
        this.messages = new ArrayList<>();
        // Initialize with test data
        initializeTestData();
    }
    
    private void initializeTestData() {
        messages.add(new Message("1", "+27834557896", null, "Did you get the cake?", "Sent"));
        messages.add(new Message("2", "+27838884567", null, "Where are you? You are late! I have asked you to be on time.", "Stored"));
        messages.add(new Message("3", "+27834484567", null, "Yohoooo, I am at your gate.", "Disregard"));
        messages.add(new Message("4", null, "0838884567", "It is dinnertime!", "Sent"));
        messages.add(new Message("5", "+27838884567", null, "Ok, I am leaving without you.", "Stored"));
    }
    
    // 1. Search messages by recipient
    public List<String> searchMessagesByRecipient(String recipient) {
        return messages.stream()
                .filter(msg -> recipient.equals(msg.getRecipient()))
                .filter(msg -> "Sent".equals(msg.getFlag()) || "Stored".equals(msg.getFlag()))
                .map(Message::getContent)
                .collect(Collectors.toList());
    }
    
    // 2. Delete message by content (using hash/equals)
    public String deleteMessage(String content) {
        boolean removed = messages.removeIf(msg -> content.equals(msg.getContent()));
        if (removed) {
            return "Message \"" + content + "\" successfully deleted.";
        }
        return "Message not found.";
    }
    
    // 3. Generate report of all sent messages
    public List<Message> generateSentMessagesReport() {
        return messages.stream()
                .filter(msg -> "Sent".equals(msg.getFlag()))
                .collect(Collectors.toList());
    }
    
    // Helper method to print report
    public void printSentMessagesReport() {
        System.out.println("\n=== Sent Messages Report ===");
        System.out.printf("%-12s %-15s %s%n", "Message Hash", "Recipient", "Message");
        System.out.println("--------------------------------------------");
        
        generateSentMessagesReport().forEach(msg -> 
            System.out.printf("%-12s %-15s %s%n", 
                msg.getMessageId(), 
                msg.getRecipient() != null ? msg.getRecipient() : msg.getDeveloper(), 
                msg.getContent())
        );
    }
    
    public static void main(String[] args) {
        MessageSystem system = new MessageSystem();
        
        // Test 1: Search messages by recipient
        System.out.println("Test 1: Search messages by recipient (+27838884567)");
        List<String> recipientMessages = system.searchMessagesByRecipient("+27838884567");
        System.out.println("Expected: [\"Where are you? You are late! I have asked you to be on time.\", \"Ok, I am leaving without you.\"]");
        System.out.println("Actual: " + recipientMessages);
        System.out.println();
        
        // Test 2: Delete message by content
        System.out.println("Test 2: Delete message (Test Message 2)");
        String contentToDelete = "Where are you? You are late! I have asked you to be on time.";
        String deleteResult = system.deleteMessage(contentToDelete);
        System.out.println("Expected: Message \"" + contentToDelete + "\" successfully deleted.");
        System.out.println("Actual: " + deleteResult);
        System.out.println();
        
        // Test 3: Display report of sent messages
        System.out.println("Test 3: Display report of sent messages");
        system.printSentMessagesReport();
    }
}
   
