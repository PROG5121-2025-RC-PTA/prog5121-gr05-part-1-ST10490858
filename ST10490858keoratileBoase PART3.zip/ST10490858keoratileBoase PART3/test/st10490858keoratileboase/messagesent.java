/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

/**
 *
 * @author RC_Student_lab
 */
public class messagesent {
    String id;
    String sender;
    String recipient;
    String content;
    String hash;
    
    void Message(String id, String sender, String recipient, String content, String hash) {
        this.id = id;
        this.sender  = sender;
        this.recipient = recipient;
        this.content = content;
        this.hash = hash;
    
    
}

messagesent(){


}
@Override
public String toString(){
    return"ID: " +id + ", Sender: " + sender + ", Content: "content + ", Hash: "hash + " ;
}
    return "ID: " + id + ", Sender: " + sender + ", Content: " + content + ", Hash: " + hash + ", ;

int length() {
    throw new UnserparatedOperationException("Not supported yet.");
}


String getContent() {
    throw new UnsupportedOperationException("Not supported yet.");
}
}