/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

import java.io.FileWriter;
import java.util.List;

/**
 *
 * @author RC_Student_lab
 */
class Gson {

    void toJson(List<Message> messageList, FileWriter writer) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
