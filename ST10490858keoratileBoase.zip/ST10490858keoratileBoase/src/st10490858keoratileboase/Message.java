/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

import java.util.*;
import java.util.regex.*;
import java.io.*;
/**
 *
 * @author RC_Student_lab
 */
public class Message {
    

    private String messageID;
    private String messageHash;
    private String recipient;
    private String messageText;
    private static int totalMessages = 0;
    private static List<Message> messageList = new ArrayList<>();

    public Message(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
        this.recipient = recipient;
        this.messageText = messageText;
        totalMessages++;
        messageList.add(this);
    }

    // Generate a random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        return String.format("%010d", rand.nextInt(1000000000));
    }

    // Check message ID length
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Check recipient cell number
    public int checkRecipientCell() {
        if (recipient.length() <= 10 && recipient.startsWith("+")) {
            return 1; // valid
        } else {
            return 0; // invalid
        }
    }

    // Create message hash: first 2 digits of ID + ":" + message number + ":" + first and last words
    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : "";
        String hash = messageID.substring(0, 2) + ":" + totalMessages + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    public String sentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose an option: 1) Send 2) Disregard 3) Store");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                return "Message sent.";
            case 2:
                return "Message disregarded.";
            case 3:
                storeMessage();
                return "Message stored.";
            default:
                return "Invalid choice.";
        }
    }

    public void printMessages() {
        for (Message msg : messageList) {
            System.out.println("ID: " + msg.messageID + ", Hash: " + msg.messageHash + ", Recipient: " + msg.recipient + ", Message: " + msg.messageText);
        }
    }

    public int returnTotalMessages() {
        return totalMessages;
    }

    // Store messages to JSON file
    public void storeMessage() {
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter("messages.json")) {
            gson.toJson(messageList, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
    

