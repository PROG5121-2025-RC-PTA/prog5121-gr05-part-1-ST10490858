/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

import java.io.OutputStream;
import java.io.PrintWriter;

/**
 *
 * @author RC_Student_lab
 */
public class PrinterWriter extends PrintWriter {

    public PrinterWriter(OutputStream outputStream, boolean b); {
   
    }
    
}
