/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10490858keoratileboase;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class ST10490858keoratileBoase {
   
    String password = null;
    String username = null;
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String status1 = "login successful";
        String status2 = "login successful";
        
        //Server address
        String severAddress = "localhost";
        int severPort = 12345;
        
        
        
            
            
        //Enter username as required
       Scanner scanner = new Scanner(System.in);
        String Username;

        while (true) {
            System.out.print("Please enter your Username: ");
            Username = scanner.nextLine();

            if (Username.contains("_") && Username.length() <= 5) {
                
                System.out.println("Username accepted " + Username);
               
            } else {
                System.out.println("Please re enter your Username you have entered a wrong format Username");
            }
        
        
        //Enter password as required 
            System.out.println("Enter your password");
                 String password = scanner.nextLine();
         
        
          String passwordRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()]).{8,}$";

         int number = 0-9;
         String upperCase = "A-Z";
        
         
        
            System.out.print("Please enter your password ");
            password = scanner.nextLine();
          

             if (password.matches(passwordRegex)) {
                System.out.println("Password accepted!");
                break;
            } else {
                System.out.println("Invalid password. It must be at least 8 characters long, include at least one digit, one uppercase letter, one lowercase letter, one special character (!@#$%^&*()), and contain no spaces.");
            
                break;
             }
        }

        System.out.print("Please enter your cellphone(e.g. +1 1234567890): ");
        String cellPhoneNumber = scanner.nextLine();
        String regex = "^\\+\\d{1,4}\\d{9}";
        
        if  (cellPhoneNumber.length()==13&&
            cellPhoneNumber.startsWith("+27")&&
            cellPhoneNumber.matches(regex)){
            System.out.println("cellphone number captured successful ");
        } else {
            System.out.println("You have entered a wrong password.");
        }

        scanner.close();
    }

    }
        



    

    
        
    
    

        
    

    

    
    
