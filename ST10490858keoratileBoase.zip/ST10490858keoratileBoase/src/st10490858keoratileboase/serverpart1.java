/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

import java.io.PrintWriter;
import java.io.*;
import java.net.*;

/**
 *
 * @author RC_Student_lab
 */
public class serverpart1 {
    
    public static void main(String [] args) {
        String severAddress = "localhost";  //Server address
        int severPort = 12345;  //Server port
        
        try (Socket socket = new Socket(serverAddress, serverPort);
                BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
                PrintWriter output = new PrinterWriter(socket.getOutputStream(), true);
                BufferedReader serverInput = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            
            
            //Get username and password from the user
            System.out.print("Enter your username" );
            String username = userInput.readLine();
            System.out.print("Enter password: ");
            String password = userInput.readLine();
            
            //Display the response from server
            String response = serverInput.readLine();
            System.out.println("Server response: " + response);
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
                   
            
        }
    }
}
