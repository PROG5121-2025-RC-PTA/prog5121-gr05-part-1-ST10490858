/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10490858keoratileboase;

/**
 *
 * @author RC_Student_lab
 */
public class validatorchat {
    

    // Check username
    public static boolean checkUserName(String username) {
        return username.matches("^\\w{1,5}_\\w*$") && username.contains("_");
    }

    // Check password 
    public static boolean checkPasswordComplexity(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$";
        return password.matches(regex);
    }

    // Check cellphone number
    public static boolean checkCellPhoneNumber(String cellNumber) {
        // AI tool (ChatGPT) helped generate regex: ^\+27\d{9}$
        return cellNumber.matches("^\\+27\\d{9}$");
    }
}
    

